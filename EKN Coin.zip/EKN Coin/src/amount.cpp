// Copyright (c) 2009-2010 Lee Golden
// Copyright (c) 2009-2014 The Bitcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include "amount.h"

#include "tinyformat.h"

CFeeRate::CFeeRate(const CAmount& nFeePaid, size_t nSize)
{
    if (nSize > 0)
        nDivixsPerK = nFeePaid*1000/nSize;
    else
        nDivixsPerK = 0;
}

CAmount CFeeRate::GetFee(size_t nSize) const
{
    CAmount nFee = nDivixsPerK*nSize / 100000; //1000

    if (nFee == 0 && nDivixsPerK > 0)
        nFee = nDivixsPerK;

    return nFee;
}

std::string CFeeRate::ToString() const
{
    return strprintf("%d.%08d DOGE/kB", nDivixsPerK / COIN, nDivixsPerK % COIN);
}
