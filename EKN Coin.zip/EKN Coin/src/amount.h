// Copyright (c) 2009-2010 Lee Golden
// Copyright (c) 2009-2014 The Bitcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef BITCOIN_AMOUNT_H
#define BITCOIN_AMOUNT_H

#include "serialize.h"

#include <stdlib.h>
#include <string>

typedef int64_t CAmount;

static const CAmount COIN = 100000000; //
static const CAmount CENT = 1000000;

/** No amount larger than this (in Divix) is valid */
static const CAmount MAX_MONEY = 10000000 * COIN; // EKN: maximum of 100B coins (given some randomness), max transaction 10,000,000,000
inline bool MoneyRange(const CAmount& nValue) { return (nValue >= 0 && nValue <= MAX_MONEY); }

/** Type-safe wrapper class to for fee rates
 * (how much to pay based on transaction size)
 */
class CFeeRate
{
private:
    CAmount nDivixsPerK; // unit is Divixs-per-1,000-bytes
public:
    CFeeRate() : nDivixsPerK(0) { }
    explicit CFeeRate(const CAmount& _nDivixsPerK): nDivixsPerK(_nDivixsPerK) { }
    CFeeRate(const CAmount& nFeePaid, size_t nSize);
    CFeeRate(const CFeeRate& other) { nDivixsPerK = other.nDivixsPerK; }

    CAmount GetFee(size_t size) const; // unit returned is Divixs
    CAmount GetFeePerK() const { return GetFee(1000); } // Divixs-per-1000-bytes

    friend bool operator<(const CFeeRate& a, const CFeeRate& b) { return a.nDivixsPerK < b.nDivixsPerK; }
    friend bool operator>(const CFeeRate& a, const CFeeRate& b) { return a.nDivixsPerK > b.nDivixsPerK; }
    friend bool operator==(const CFeeRate& a, const CFeeRate& b) { return a.nDivixsPerK == b.nDivixsPerK; }
    friend bool operator<=(const CFeeRate& a, const CFeeRate& b) { return a.nDivixsPerK <= b.nDivixsPerK; }
    friend bool operator>=(const CFeeRate& a, const CFeeRate& b) { return a.nDivixsPerK >= b.nDivixsPerK; }
    std::string ToString() const;

    ADD_SERIALIZE_METHODS;

    template <typename Stream, typename Operation>
    inline void SerializationOp(Stream& s, Operation ser_action, int nType, int nVersion) {
        READWRITE(nDivixsPerK);
    }
};

#endif //  BITCOIN_AMOUNT_H
