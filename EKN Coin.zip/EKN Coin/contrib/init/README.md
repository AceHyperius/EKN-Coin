Sample configuration files for:

SystemD: EKNd.service
Upstart: EKNd.conf
OpenRC:  EKNd.openrc
         EKNd.openrcconf
CentOS:  EKNd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
