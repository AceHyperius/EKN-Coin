
Debian
====================
This directory contains files used to package EKNd/EKN-qt
for Debian-based Linux systems. If you compile EKNd/EKN-qt yourself, there are some useful files here.

## EKN: URI support ##


EKN-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install EKN-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your EKN-qt binary to `/usr/bin`
and the `../../share/pixmaps/bitcoin128.png` to `/usr/share/pixmaps`

EKN-qt.protocol (KDE)

